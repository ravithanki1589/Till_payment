<?php

echo "<pre>";
print_r($_POST);
print_r($_GET);
$rawPostData = file_get_contents('php://input');
print_r($rawPostData);

$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$txt = $rawPostData;
fwrite($myfile, $txt);
$txt = $rawPostData;
fwrite($myfile, $txt);
fclose($myfile);
?>