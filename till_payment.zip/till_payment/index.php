<?php

$username      = 'SynergyAlliance_API_Dev';
$password      = 'KPY5kapej3Dhzh8reTdVbx2J8h2DPS!';
$api_key       = 'K5cIRU4wijllQVT4YfHdRPJOvFurpQ';
$shared_secret = 'V6grrta6YdpjNIXDkJWt3heUJFlu8Z';
$public_file   = 'e1d33j2LJW9Yj5EsjOuv';

$username_password = base64_encode($username.':'.$password);
//$method = 'POST';
//$json = {"merchantTransactionId": "2019-09-02-0004","amount": "9.99","currency": "EUR"};


require 'vendor/autoload.php';

$headers = [
  'Content-Type' => 'application/json',
  'Accept' => 'application/json',
  'Authorization'=> 'Basic '.$username_password,
];

$client = new \GuzzleHttp\Client();

// Define array of request body.
$request_body = [];
$request_body['merchantTransactionId'] = (string)time();
$request_body['amount'] = '0.65';
$request_body['currency'] = 'AUD';
$request_body['successUrl'] = 'http://localhost/payment_gateway/till_payment/success.php';
$request_body['cancelUrl'] = 'http://localhost/payment_gateway/till_payment/cancel.php';
$request_body['errorUrl'] = 'http://localhost/payment_gateway/till_payment/error.php';
$request_body['callbackUrl'] = 'http://localhost/payment_gateway/till_payment/callback.php';
$request_body['description'] = 'Qrmenu Order';

$request_body['customer']['firstName'] = 'Ravi';
$request_body['customer']['lastName'] = 'Thanki';
$request_body['customer']['email'] = 'ravi_thanki@waytoweb.in';
$request_body['customer']['ipAddress'] = '127.0.0.1';

try {
  $response = $client->request('POST','https://test-gateway.tillpayments.com/api/v3/transaction/O6ZLZ8P6waZ9u5Vk3iytUK0WAskgLs/debit', [
    'headers' => $headers,
    'json' => $request_body,
  ]);
  $data = $response->getBody()->getContents();
  $data = json_decode($data);
  echo "<pre>";
  print_r($data);
  header("Location:".$data->redirectUrl);
} catch (\GuzzleHttp\Exception\BadResponseException $e) {
  // handle exception or api errors.
  print_r($e->getMessage());
}
?>	